#!/bin/bash
/etc/init.d/cron start & 
/usr/sbin/sshd -D 
